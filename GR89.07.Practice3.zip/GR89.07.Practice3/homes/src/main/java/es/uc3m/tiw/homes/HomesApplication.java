package es.uc3m.tiw.homes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomesApplication.class, args);
	}
}
